function [z, p, k] = besselFilterAnalogZerosPolesAndGain(N, wc, mode, G);

% This function computes s-plane zeros, poles and a gain factor for an 
% analog Bessel filter of order "N" with radian cutoff frequency "wc".
%
% usage: 
%  [z, p, k] = besselFilterAnalogZerosPolesAndGain(N, wc, mode, G);
%
% input-variables:
%  -N: order of the filter
%  -wc: radian cutoff frequency in Hz (= 2*pi* cutoff in Hz), in case of
%       bandpass or bandstop filters, this should be a two-element vector
%  -mode: a string specifying the filter mode ('LP', 'HP', 'BP', 'BR',
%         'LS', 'HS', 'PK')
%  -G: gain for peak- and shelving filters (as raw amplitude factor)
%
% output-variables:
%  -z: z-plane zeros
%  -p: z-plane poles
%  -k: gain factor

%--------------------------------------------------------------------------

[z, p, k] = besselFilterPrototype(N);

if( strcmp(mode, 'LS') || strcmp(mode, 'HS') || strcmp(mode, 'PK') )
 [z, p, k] = analogLowpassToLowshelf(z, p, k, G, 1);
end
[z, p, k] = analogFrequencyTransform(z, p, k, wc, mode);
