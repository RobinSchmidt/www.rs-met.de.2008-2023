function [zd, pd, kd] = analogToDigitalBilinear(z, p, k, fs);

% This function performs s-domain to z-domain mapping of zeros, poles and 
% the overall gain factor of an analog filter's transfer function.
%
% usage: 
%  [zd, pd, kd] = analogToDigitalBilinear(z, p, k, fs);
%
% input-variables:
%  -z: s-domain zeros of the analog transfer function
%  -p: s-domain poles of the analog transfer function
%  -k: gain factor of the analog transfer function
%  -fs: samplerate
%
% output-variables:
%  -zd: z-domain zeros of the digital transfer function
%  -pd: z-domain poles of the digital transfer function
%  -kd: gain factor of the digital transfer function

%--------------------------------------------------------------------------

scaler = 0.5/fs;

pd = zeros(length(p), 1);
for n=1:length(p)
 tmp   = scaler * p(n);
 pd(n) = (1.0+tmp)/(1.0-tmp);
end

numZeros = max(length(p), length(z));
zd       = zeros(numZeros, 1);
for n=1:numZeros
 if( n > length(z) || abs(z(n)) == inf )
  zd(n) = -1;
 else
  tmp   = scaler * z(n);
  zd(n) = (1.0+tmp)/(1.0-tmp);
 end
end

num = 1;
for n=1:length(z)
 if( abs(z(n)) ~= inf )
  num = num * (2*fs-z(n));
 end
end
den = prod(2*fs-p);
kd  = k*num/den;
