function wp = prewarpedRadianFrequency(f, fs);

% Computes the prewarped radian frequency for some frequency "f" at
% samplerate "fs". The returned radian frequency "wp" will correspond to 
% the frequency "f" when the bilinear transform is used to obtain a digital
% filter from an analog filter.
%
% usage: 
%  wp = prewarpedRadianFrequency(f, fs);
%
% input-variables:
%  -f: frequency to be warped (in Hz)
%  -fs: samplerate (in Hz)
%
% output-variables:
%  -wp: prewarped radian frequency corresponding to "f" at samplerate "fs"

%--------------------------------------------------------------------------

wp = 2.0*fs*tan(pi*f/fs);
