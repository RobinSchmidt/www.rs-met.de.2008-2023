function y = onlyLeftHalfPlane(x);

% Given an array of complex numbers, this function returns only thoses that
% are in the left half plane (icluding the imaginary axis).
%
% usage: 
%  y = onlyLeftHalfPlane(x);
%
% input-variables:
%  -x: array of complex numbers
%
% output-variables:
%  -y: array containing only those members of x that are in the left half
%      plane

%--------------------------------------------------------------------------

y = [];
for n=1:length(x)
 if( real(x(n)) <= 0 )
  y = [y x(n)];
 end
end
