function a = besselPolynomial2(order);

% This function generates the polynomial coefficients for a Bessel
% polynomial of the given order. It uses a simpler recursion formula than
% besselPolynomial.m - it may have different numerical behavior in extreme
% cases (for the better or worse).
%
% usage: 
%  a = besselPolynomial(order);
%
% input-variables:
%  -order: order of the Bessel polynomial
%
% output-variables:
%  -a: the polynomial coefficients. When "N" is the order and "a" is the 
%      vector of the coefficients for a polynomial p(x), the coefficients 
%      are in the format: p(x) = a(1) * x^N + a(2) * x^(N-1) + ... + a(N+1)

%--------------------------------------------------------------------------

N    = order;
a    = zeros(N+1, 1);
a(1) = 1;
for k = 0:N-1
 a(k+2) = (2*(N-k)*a(k+1)) / ((2*N-k)*(k+1));
end
a = a / a(N+1);
