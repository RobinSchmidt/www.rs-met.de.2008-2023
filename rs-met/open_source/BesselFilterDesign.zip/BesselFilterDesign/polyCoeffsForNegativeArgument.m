function am = polyCoeffsForNegativeArgument(a);

% Given an array of polynomial coefficients (format should be as used in
% roots, etc.), this function returns the coefficients for a polynoimal
% that would have a negative on the argument. That is, if the coeffs for a
% polynomial y = p(x) are given, it returns the coefficients for a
% polynomial q(x), such that q(x) = p(-x). In effect, it just inverts the
% sign for all coefficients that multiply odd powers of x.
%
% usage: 
%  am = polyCoeffsForNegativeArgument(a);
%
% input-variables:
%  -a: coefficients of the input polynomial p(x)
%
% output-variables:
%  -am: coefficients of the output polynomial q(x) such that q(x) = p(-x)

%--------------------------------------------------------------------------

am = a;
for n=0:length(am)-1
 if( mod(n,2) == 1 )
  am(length(am)-n) = -am(length(am)-n);
 end
end
