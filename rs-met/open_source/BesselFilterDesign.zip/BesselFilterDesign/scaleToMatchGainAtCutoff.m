function [zNew, pNew, kNew] = scaleToMatchGainAtCutoff(z, p, k, A);

% Scales zeros, poles and gain factor of an analog lowpass prototype filter 
% such that the magnitude value of "A" is attained at the cutoff frequency 
% of unity.
%
% usage: 
%  [zNew, pNew, kNew] = scaleToMatchGainAtCutoff(z, p, k, A);
%
% input-variables:
%  -z: array of s-plane zeros of the transfer function
%  -p: array of s-plane poles of the transfer function
%  -k: global gain factor of the transfer function
%  -A: gain value at which we define the cutoff frequency

% output-variables:
%  -zNew: scaled zeros
%  -pNew: scaled poles
%  -kNew: scaled gain factor

%--------------------------------------------------------------------------

wc   = findPrototypeCutoff(z, p, k, A);
zNew = z ./ wc;
pNew = p ./ wc; 
kNew = k  / wc^(length(p)-length(z)); 
