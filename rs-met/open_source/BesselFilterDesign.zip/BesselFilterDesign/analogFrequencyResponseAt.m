function H = analogFrequencyResponseAt(z, p, k, w);

% Given an array of s-plane zeros "z", an array of s-plane poles "p" and a
% global gain factor, this function computes the complex frequency response
% of the analog filter with these poles, zeros and gain at the radian 
% frequency "w".
%
% usage: 
%  H = analogFrequencyResponseAt(z, p, k, w);
%
% input-variables:
%  -z: array of s-plane zeros of the transfer function
%  -p: array of s-plane poles of the transfer function
%  -k: global gain factor of the transfer function
%  -w: radian frequency at which to evaluate the frequency response

% output-variables:
%  -H: the complex frequency response value at radian frequency "w"

%--------------------------------------------------------------------------

s = j*w; % s-value at which to evaluate H(s)

% compute numerator:
num = 1; 
for n=1:length(z)
 if( abs(z(n)) ~= inf )
  num = num * (s - z(n));
 end
end

% compute denominator:
den = 1;  
for n=1:length(p)
 den = den * (s - p(n));
end

H = k * num / den; 
