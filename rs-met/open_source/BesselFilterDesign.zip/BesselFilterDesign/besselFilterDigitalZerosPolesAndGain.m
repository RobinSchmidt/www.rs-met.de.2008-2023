function [z, p, k] = besselFilterDigitalZerosPolesAndGain(N, fc, fs, ... 
                      mode, G);

% This function computes z-plane zeros, poles and a gain factor for a 
% digital Bessel filter of order N with cutoff frequency fc at samplerate 
% fs (both given in Hz). 
%
% usage: 
%  [z, p, k] = besselFilterDigitalZerosPolesAndGain(N, fc, fs, mode, G);
%
% input-variables:
%  -N: order of the filter
%  -fc: cutoff frequency in Hz (in case of bandpass or bandstop mode, this
%       should be a two-element vector)
%  -fs: samplerate in Hz
%  -mode: a string specifying the filter mode ('LP', 'HP', 'BP', 'BR',
%         'LS', 'HS', 'PK')
%  -G: gain for peak- and shelving filters (as raw amplitude factor)
%
% output-variables:
%  -z: z-plane zeros
%  -p: z-plane poles
%  -k: gain factor

%--------------------------------------------------------------------------

wp        = prewarpedRadianFrequency(fc, fs);
[z, p, k] = besselFilterAnalogZerosPolesAndGain(N, wp, mode, G);
[z, p, k] = analogToDigitalBilinear(z, p, k, fs);
