function [zNew, pNew, kNew] = analogLowpassToLowpass(z, p, k, w);

% This function performs s-domain frequency mapping of the given poles,
% zeros and gain-factor. The original values are assumed to represent an 
% analog prototype filter with nominal radian cutoff frequency at unity. 
% The new values will represent an analog lowpass filter with the desired
% radian cutoff frequency given by 'w'.
%
% usage: 
%  [zNew, pNew, kNew] = analogLowpassToLowpass(z, p, k, w);
%
% input-variables:
%  -z: s-domain zeros of the prototype transfer function
%  -p: s-domain poles of the prototype transfer function
%  -k: gain factor of the prototype transfer function
%  -w: desired normalized radian cutoff frequency
%
% output-variables:
%  -zNew: zeros of the new transfer function
%  -pNew: poles of the new transfer function
%  -kNew: gain factor of the new transfer function

%--------------------------------------------------------------------------

zNew = w*z;
pNew = w*p;
kNew = k * w^length(p) / w^length(z);
