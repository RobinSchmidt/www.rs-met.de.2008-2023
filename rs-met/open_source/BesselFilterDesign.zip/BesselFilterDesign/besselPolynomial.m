function a = besselPolynomial(order);

% This function generates the polynomial coefficients for a Bessel
% polynomial of the given order.
%
% usage: 
%  a = besselPolynomial(order);
%
% input-variables:
%  -order: order of the Bessel polynomial
%
% output-variables:
%  -a: the polynomial coefficients. When "N" is the order and "a" is the 
%      vector of the coefficients for a polynomial p(x), the coefficients 
%      are in the format: p(x) = a(1) * x^N + a(2) * x^(N-1) + ... + a(N+1)

%--------------------------------------------------------------------------

a = zeros(order+1, 1);
    
if( order == 0 )
 a(1) = 1;
elseif( order == 1 )
 a(1) = 1;
 a(2) = 1;
else % recursion

 a(1)  = 1;
 b1    = zeros(order+1, 1);
 b2    = zeros(order+1, 1);
 b2(1) = 1;
 b2(2) = 0;
 b1(1) = 1;
 b1(2) = 1;
 
 for n=2:order
  c = 2*n-1;
  
  for m=n:-1:1
   a(m+1) = c*b1(m);
  end
  
  a(1) = 0;
  
  for m=0:n-2
   a(m+1) = a(m+1) + b2(m+1);
  end
  
  for m=0:n-1
   b2(m+1) = b1(m+1);
  end
  
  for m=0:n
   b1(m+1) = a(m+1);
  end
  
 end
 
end

a = flipud(a);
