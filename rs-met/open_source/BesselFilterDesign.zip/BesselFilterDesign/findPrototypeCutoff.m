function w = findPrototypeCutoff(z, p, k, A);

% Given an array of s-plane zeros "z", an array of s-plane poles "p" and a
% global gain factor "k" of a lowpass(!) prototype filter, this function 
% computes the radian frequency at which the magnitude response of the 
% filter attains the value given by "A". Note that when the filter has 
% ripple such that the desired magnitude value is attained at several 
% frequencies, it may return any of these frequencies. This means, this 
% function can used safely only for filters magnitude responses where the
% value "A" is taken on exactly once.
%
% usage: 
%  w = findPrototypeCutoff(z, p, k, A);
%
% input-variables:
%  -z: array of s-plane zeros of the transfer function
%  -p: array of s-plane poles of the transfer function
%  -k: global gain factor of the transfer function
%  -A: gain value at which we define the cutoff frequency

% output-variables:
%  -w: frequency at which the magnitude is "A"

%--------------------------------------------------------------------------

if( A <= 0 || A >= 1 )
 error('A must be between 0 and 1 (exclusive) in findPrototypeCutoff');
end

% determine the frequency interval in which the magnitude value A must 
% fall:
wL = 1;
wU = 1;
while( abs(analogFrequencyResponseAt(z,p,k,wL)) < A )
 wL = wL/2;
end
while( abs(analogFrequencyResponseAt(z,p,k,wU)) > A )
 wU = wU*2;
end
% note when the filter has ripple, it is necesarry to shrink/expand the 
% interval more slowly (depending on the density of the ripple near w=1

% find the frequency at which the magnitude is equal to A by bisection:
i    = 0;         % iteration counter
iMax = 1000;      % maximum number of iterations
tol  = 2*eps;     % tolerance
wM   = (wL+wU)/2; % midpoint
wOld = wM;        % to remember wM from previous iteration
AM   = abs(analogFrequencyResponseAt(z,p,k,wM));
while( abs(AM-A) > tol && i < iMax )
 if( AM > A )
  wL = wM;
 elseif( AM < A )
  wU = wM;
 end
 wOld = wM;
 wM   = (wL+wU)/2;
 AM   = abs(analogFrequencyResponseAt(z,p,k,wM));
 i    = i+1;
 if( abs(wM-wOld) < eps*min(wOld, wM) ) 
  break;  % 2nd convergence criterion based on frequency difference
 end
end
w = wM;

if( i == iMax )
 disp('Slow convergence in findPrototypeCutoff');
end
