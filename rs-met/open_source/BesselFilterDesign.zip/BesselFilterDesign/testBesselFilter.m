clear all;

% This script demonstrates the usage of the implementation of the Bessel 
% filter design toolbox. Simply modify the values of the variables in the
% "user parameters" section to try different settings.

% user parameters:
mode  = 'PK';     % mode of the filter (LP, HP, BP, BR, LS, HS, PK)
order = 5;       % prototype filter order (BP, BR and PK will have actual 
                  % order twice as high)            
fs    = 44100;    % samplerate in Hz
fc1   = 0.2*fs/2; % cutoff frequency in Hz
fc2   = 0.4*fs/2; % 2nd cutoff (only relevant for bandpass and bandstop)
GdB   = +10;       % gain for peak/shelf filters in decibels

% the actual filter design and visualization of the result:
G = 10^(GdB/20); 
if( strcmp(mode, 'LP') || strcmp(mode, 'HP') ||...
    strcmp(mode, 'LS') || strcmp(mode, 'HS')       )
 fc = fc1;
else
 fc = [fc1, fc2];
end
[b, a] = besselFilterDirectForm(order, fc, fs, mode, G);
freqz(b, a);
