function [z, p, k] = besselFilterPrototype(order);

% Returns the s-plane zeros, poles and gain factor for an analog Bessel 
% prototype filter of given order.
%
% usage: 
%  [z, p, k] = besselFilterPrototype(order);
%
% input-variables:
%  -order: order of the filter
%
% output-variables:
%  -z: s-pane zeros of the transfer function
%  -p: s-pane poles of the transfer function
%  -k: gain factor

%--------------------------------------------------------------------------

a = besselPolynomial(order);
a = flipud(a); % we  actually need the reverse Bessel polynomial 

z = [];   
p = roots(a);  
k = a(order+1);

% scale poles and gain-factor to asymptotically match Butterworth response:
p = p / k^(1/order);
k = 1;
