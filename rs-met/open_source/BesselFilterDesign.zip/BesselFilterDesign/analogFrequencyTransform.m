function [zNew, pNew, kNew] = analogFrequencyTransform(z, p, k, w, mode);

% This function performs s-domain frequency mapping of the given poles
% zeros and gain factor.
%
% usage: 
%  [zNew, pNew, kNew] = analogFrequencyTransform(z, p, k, w, mode);
%
% input-variables:
%  -z: s-domain zeros of the prototype transfer function
%  -p: s-domain poles of the prototype transfer function
%  -k: gain factor of the prototype transfer function
%  -w: desired normalized radian cutoff frequency (in case of bandpass or 
%      bandstop mode, this should be a two-element vector)
%  -mode: desired mode of the filter ('LP', 'HP', 'BP' or 'BS')
%
% output-variables:
%  -zNew: zeros of the new transfer function
%  -pNew: poles of the new transfer function
%  -kNew: gain factor of the new transfer function

%--------------------------------------------------------------------------

if( length(w) == 2 )
 if( strcmp(mode, 'BP') || strcmp(mode, 'PK') )
  [zNew, pNew, kNew] = analogLowpassToBandpass(z, p, k, w);
 elseif( strcmp(mode, 'BR') )
  [zNew, pNew, kNew] = analogLowpassToBandstop(z, p, k, w);
 end
else
 if( strcmp(mode, 'LP') || strcmp(mode, 'LS') )
  [zNew, pNew, kNew] = analogLowpassToLowpass(z, p, k, w);
 elseif( strcmp(mode, 'HP') || strcmp(mode, 'HS') )
  [zNew, pNew, kNew] = analogLowpassToHighpass(z, p, k, w);
 end
end
