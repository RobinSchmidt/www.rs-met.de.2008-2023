function [zNew, pNew, kNew] = analogLowpassToBandstop(z, p, k, w);

% This function performs s-domain frequency mapping of the given poles,
% zeros and gain-factor. The original values are assumed to represent an 
% analog prototype filter with nominal radian cutoff frequency at unity. 
% The new values will represent an analog bandstop filter with the desired
% radian cutoff frequencies given by the two-element vector 'w'.
%
% usage: 
%  [zNew, pNew, kNew] = analogLowpassToBandstop(z, p, k, w);
%
% input-variables:
%  -z: s-domain zeros of the prototype transfer function
%  -p: s-domain poles of the prototype transfer function
%  -k: gain factor of the prototype transfer function
%  -w: two-element vector of desired normalized radian cutoff frequencies
%
% output-variables:
%  -zNew: zeros of the new transfer function
%  -pNew: poles of the new transfer function
%  -kNew: gain factor of the new transfer function

%--------------------------------------------------------------------------

wc   = sqrt(w(1)*w(2));  % center (radian) frequency
bw   = w(2) - w(1);      % bandwidth
pNew = zeros(2 * length(p), 1);
zNew = zeros(2 * length(z), 1);

for n=1:length(p)
 tmp1        = 0.5 * bw / p(n);
 tmp2        = -bw / p(n);
 tmp2        = 0.25 * tmp2*tmp2;
 tmp2        = sqrt(tmp2 - wc*wc);
 pNew(2*n-1) = tmp1 + tmp2;
 pNew(2*n)   = tmp1 - tmp2;
end

for n=1:length(z)
 tmp1        = 0.5 * bw / z(n);
 tmp2        = -bw / z(n);
 tmp2        = 0.25 * tmp2*tmp2;
 tmp2        = sqrt(tmp2 - wc*wc);
 zNew(2*n-1) = tmp1 + tmp2;
 zNew(2*n)   = tmp1 - tmp2;
end

for n=(length(zNew)+1):2:length(pNew)
 zNew(n)   =  j*wc;
 zNew(n+1) = -j*wc;
end

kNew = k * (-1)^(length(p) + length(z)) * prod(z) / prod(p);
