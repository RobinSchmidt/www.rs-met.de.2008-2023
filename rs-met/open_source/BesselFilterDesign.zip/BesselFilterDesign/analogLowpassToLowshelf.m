function [zNew, pNew, kNew] = analogLowpassToLowshelf(z, p, k, G, G0);

% This function performs s-domain frequency mapping of the given poles,
% zeros and gain-factor. The original values are assumed to represent an 
% analog lowpass prototype filter with nominal radian cutoff frequency at 
% unity. The new values will represent an analog low-shelving filter in 
% which the scaled lowpass transfer function will be added to a constant
% pedestal.
%
% usage: 
%  [zNew, pNew, kNew] = analogLowpassToLowshelf(z, p, k, G, G0);
%
% input-variables:
%  -z: s-domain zeros of the lowpass prototype transfer function
%  -p: s-domain poles of the lowpass prototype transfer function
%  -k: gain factor of the lowpass prototype transfer function
%  -G: gain value, if the lowpass prototype has unit gain at DC, the
%      shelving filter will have a gain of "G" at DC
%  -G0: value for the constant offset
%
% output-variables:
%  -zNew: zeros of the new transfer function
%  -pNew: poles of the new transfer function
%  -kNew: gain factor of the new transfer function

%--------------------------------------------------------------------------

if( G0 == 0 )
 zNew = z;
 pNew = p;
 kNew = G*k;
else
 
 % we design a boost filter in any case - a dip filter will later be 
 % obtained by swapping poles and zeros:
 dip = false;
 if( G < G0 )
  dip = true;
  G   = 1/G;
  G0  = 1/G0;
 end
 
 % scale poles/zeros/gain of the lowpass such that the low-shelving 
 % filter has a gain of sqrt(G*G0) at unit frequency:
 GB = sqrt(G0*G);                   % bandwidth gain
 GC = sqrt((GB^2-G0^2)/(G^2-G0^2)); % lowpass gain at unit frequency
 [z, p, k] = scaleToMatchGainAtCutoff(z, p, k, GC);
 
 % convert poles and zeros to polynomial coefficients:
 b = poly(z);  % coeffs of N_LP(s)
 a = poly(p);  % coeffs of D_LP(s)
 
 % prepend zeros to numerator polynomial coeffs if numerator order is less
 % than denominator order:
 dN = length(a) - length(b);
 if dN > 0
  b = [zeros(dN, 1)' b];
 end
 
 % construct N_LP(s)*N_LP(-s) and D_LP(s)*D_LP(-s):
 bm = polyCoeffsForNegativeArgument(b); % coeffs of N_LP(-s)
 am = polyCoeffsForNegativeArgument(a); % coeffs of D_LP(-s)
 b2 = conv(b, bm);                      % coeffs of N_LP(s)*N_LP(-s)
 a2 = conv(a, am);                      % coeffs of D_LP(s)*D_LP(-s)
 
 % obtain coefficients for shelving filter's magnitude squared function 
 % numerator polynomial N_LS(s)*N_LS(-s):
 b2New = G0^2*a2 + k^2*(G^2-G0^2)*b2;
 
 % obtain zeros, poles and gain of the new shelving filter:
 zNew = onlyLeftHalfPlane(roots(b2New));
 pNew = p;
 kNew = sqrt(abs(b2New(1)));
 
 % pole/zero swapping and gain adjustment for dip-filters:
 if( dip == true )
  zTmp = pNew;
  pNew = zNew;
  zNew = zTmp;
  kNew = 1/kNew;
 end
 
end
